
public class ArmstrongNum {
		public static void main(String[] args){
		int n = 153;
		int s = 0;
		int c = 0;
		int k = n;
		
		//Logic to find Armstrong Number
		while(k!=0){
			s =	k%10;
			c = c + (s*s*s);
			k = k/10;
			}	
		if (n == c)
			System.out.println("This number "+n+" is an Armstrong Number");
		else
			System.out.println("This number "+n+" is not an Armstrong Number");
		}
}

