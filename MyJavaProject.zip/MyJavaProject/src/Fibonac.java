
public class Fibonac {
	public static void main(String[] args){
		int first =0;
		int second=1;
		int third=0;
		int i=0;

		System.out.print(first+" ");
		
		while(i<20){
			third = first+second; 
			System.out.print(second+" ");
			first = second;
			second = third;
			i = i+1;
		}
	}
}


//0 1 1 2 3 5 8 
/*
// not working going in loop check with Shanker
int fibo(int n){
	third = first+second; 
	System.out.print(second+" ");
	first = second;
	second = third;

}

int a = 0;
int b = 1;
a  = b, b = a+b;
*/