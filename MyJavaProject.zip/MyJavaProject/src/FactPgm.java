
public class FactPgm {

	public static void main(String[] args) {
		
		int h = fact(5);
		int temp = 1;
		for(int i=5; i>0; i--){
			temp = temp * (i);
		}
		
		System.out.println("Factorial of Given Number by regular Method is: "+ temp);
		System.out.println("Factorial of Given Number by Recursive method: "+ h);

	}
	
	public static int fact(int num){
		
		if (num >= 1){
			return num * fact(num-1);	
		}
		else return 1;
		/*  5! =  120
		  4! =  24
		  3! =  6
		  2! =  2
		  1! =  1 */
	}
}
