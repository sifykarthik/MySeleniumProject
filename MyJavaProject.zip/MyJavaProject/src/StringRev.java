
public class StringRev {

	public static void main(String[] args) {

		String s = "KARTHIK";
		String revStr1 = revStr(s);
		System.out.println(revStr1);
	}
	public static String revStr(String s){
		char[] ch = s.toCharArray();
		
		String rev = "";
		for(int i=ch.length-1;i>=0;i--){	
			rev = rev+ch[i];
		}
		return(rev);
	}
}

