public class StringTest {

	public static void main(String[] args) {

		String s1 = "Karthik";
		String s2 = "karthik  ";
		
		String s3 = new String("Karthik");
		String s4 = new String("Karthik");
		System.out.println("Memory match: "+ (s3==s4));
		System.out.println("Content match: "+ (s3.equalsIgnoreCase(s4)));
		System.out.println(s2.replace('h', 'i'));
		System.out.println(s2.trim());
		System.out.println(s2.charAt(3));
		
		System.out.println(s2.indexOf("k"));
		System.out.println(s2.lastIndexOf("k"));
		
		StringBuffer sb = new StringBuffer("Karthik");
		System.out.println(sb.reverse());
		
		System.out.println(sb.append("Keyan"));
		
		System.out.println(sb.insert(7, "****"));
		
		
		System.out.println(s1.substring(3,5));
		
	}

}
