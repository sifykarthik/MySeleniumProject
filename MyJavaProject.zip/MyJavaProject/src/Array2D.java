
public class Array2D {
	public static void main(String[] args) {
		int[][] n = new int[4][4];
		for(int i=0; i<n.length;i++){
			for(int j=0;j<n[i].length;j++){
				if (i==j){
					n[i][j]=0;
				}
				else{
					n[i][j] = 1;
				}
			}
		}
			for(int m=0; m<n.length;m++){
				for(int o=0;o<n[m].length;o++){
					System.out.print(n[m][o]+ "\t");
				}
				System.out.println();
			}
	}

}

